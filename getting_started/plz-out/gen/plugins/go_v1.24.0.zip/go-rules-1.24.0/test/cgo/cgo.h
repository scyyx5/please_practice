// GetAnswer returns the answer to the great question of Life, the Universe and Everything.
int GetAnswer();
