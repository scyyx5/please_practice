package main

import "github.com/please-build/go-rules/test/definitions/version"

func main() {
	println(version.Version)
}
