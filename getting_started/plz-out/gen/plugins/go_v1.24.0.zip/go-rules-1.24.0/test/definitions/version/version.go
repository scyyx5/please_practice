package version

var Version string = "DEVELOPMENT"
