package main

func main() {
	println("hi")
}
