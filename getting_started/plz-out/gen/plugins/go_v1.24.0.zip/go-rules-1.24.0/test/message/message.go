package message

var Message = "Hello there!"
