package main

import (
	"fmt"
)

func WhatIsTheAnswerToLifeTheUniverseAndEverything() int {
	return 42
}

func main() {
	fmt.Printf("%d\n", WhatIsTheAnswerToLifeTheUniverseAndEverything())
}
