package root

func Foo() string {
	return "Foo"
}
