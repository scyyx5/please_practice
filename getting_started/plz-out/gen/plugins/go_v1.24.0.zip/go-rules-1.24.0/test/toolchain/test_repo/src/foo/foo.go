package foo

const Foo = "wibble wibble wibble"
