package bar

const Bar = "bar"
