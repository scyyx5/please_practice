package foo

import "example.com/local_imports/bar"

func test() {
	_ = bar.Bar
}
