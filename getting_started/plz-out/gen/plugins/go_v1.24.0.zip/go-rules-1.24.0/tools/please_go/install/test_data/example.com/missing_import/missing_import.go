package foo

import noexist "github.com/doesnt-exist"

var _ = noexist.Constant
