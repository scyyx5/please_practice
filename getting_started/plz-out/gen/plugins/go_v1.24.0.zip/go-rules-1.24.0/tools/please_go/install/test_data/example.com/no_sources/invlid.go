//go:build nothing
// +build nothing

// Build constraints on this package should mean there's no valid sources
package no_sources
