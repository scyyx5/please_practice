package bench

import "testing"

func BenchmarkExample(b *testing.B) {

}
