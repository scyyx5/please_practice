# k8s-rules
Kubernetes rules for the Please build system
