#!/usr/bin/env bash
# used by the sh deps test
export TEST_DEPS_VAR="123"
