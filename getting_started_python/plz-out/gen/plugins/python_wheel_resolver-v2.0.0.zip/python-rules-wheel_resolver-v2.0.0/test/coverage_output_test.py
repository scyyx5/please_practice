#!/usr/bin/python
#
# Dummy test file for some of the e2e tests.

import unittest


class CoverageOutputTest(unittest.TestCase):

    def test_stuff(self):
        """Test that the flux capacitor is correctly calibrated."""
        self.assertEqual(2, 2)
