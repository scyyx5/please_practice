"""Part of a test on deps, data, requires and provides."""

from __future__ import print_function


def the_answer():
    return 42


if __name__ == '__main__':
    print('42')
