import unittest


class EmptyTest(unittest.TestCase):
    """Doesn't have any actual tests in it, to test how we handle that situation."""
