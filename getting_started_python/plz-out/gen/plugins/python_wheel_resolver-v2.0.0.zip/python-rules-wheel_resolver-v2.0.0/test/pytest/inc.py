def inc(x):
    """boy this is one profound function"""
    return x + 1
