from .dummy import name  # relative import to get name


def greetings():
    return 'hello world'
