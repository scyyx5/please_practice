"""This exists only as a test harness for examining slightly non-trivial coverage output."""

import sys
from collections import defaultdict


def calculate_answer(a, b):
    return a * b


def the_answer():
    return calculate_answer(
        6,
        7,
    )
