package pex

// MustAsset is a stubbed version of the function to help Go tooling.
func MustAsset(name string) []byte {
	panic("not implemented")
}
