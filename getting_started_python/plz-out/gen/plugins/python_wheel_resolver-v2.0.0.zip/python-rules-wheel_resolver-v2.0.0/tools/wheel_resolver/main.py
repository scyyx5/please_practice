from tools.wheel_resolver import main

if __name__ == "__main__":
    main()
