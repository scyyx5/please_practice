from numpy import random

def greeting():
    return random.choice(["Hello", "Bonjour", "Marhabaan"])