"""Zipfile entry point which supports auto-extracting itself based on zip-safety."""

import os
import runpy
import sys

# Put this pex on the path before anything else.
PEX = os.path.abspath(sys.argv[0])
# This might get overridden down the line if the pex isn't zip-safe.
PEX_PATH = PEX
sys.path = [PEX_PATH] + sys.path

# These will get templated in by the build rules.
MODULE_DIR = 'third_party/python'
ENTRY_POINT = 'pex_test_main'
ZIP_SAFE = True
PEX_STAMP = 'hMD4egSntCo6FTJ4NEglFfVEHAE'


def add_module_dir_to_sys_path(dirname, zip_safe=True):
    """Adds the given dirname to sys.path if it's nonempty."""
    import plz  # this needs to be imported after paths are set up
    if dirname:
        sys.path.insert(1, os.path.join(sys.path[0], dirname))
        sys.meta_path.insert(0, plz.ModuleDirImport(dirname))
    if zip_safe:
        sys.meta_path.append(plz.SoImport(MODULE_DIR))


def pex_basepath(temp=False):
    if temp:
        import tempfile
        return tempfile.mkdtemp(dir=os.environ.get('TEMP_DIR'), prefix='pex_')
    else:
        return os.environ.get('PEX_CACHE_DIR',os.path.expanduser('~/.cache/pex'))


def pex_uniquedir():
    return 'pex-%s' % PEX_STAMP


def pex_paths():
    no_cache = os.environ.get('PEX_NOCACHE')
    no_cache = no_cache and no_cache.lower() == 'true'
    basepath, uniquedir = pex_basepath(no_cache), pex_uniquedir()
    pex_path = os.path.join(basepath, uniquedir)
    return pex_path, basepath, uniquedir, no_cache


def explode_zip():
    """Extracts the current pex to a temp directory where we can import everything from.

    This is primarily used for binary extensions which can't be imported directly from
    inside a zipfile.
    """
    # Temporarily add bootstrap to sys path
    sys.path = [os.path.join(sys.path[0], '.bootstrap')] + sys.path[1:]
    import contextlib, portalocker, plz
    sys.path = sys.path[1:]

    @contextlib.contextmanager
    def pex_lockfile(basepath, uniquedir):
        # Acquire the lockfile.
        lockfile_path = os.path.join(basepath, '.lock-%s' % uniquedir)
        with open(lockfile_path, "a+") as lockfile:
            # Block until we can acquire the lockfile.
            portalocker.lock(lockfile, portalocker.LOCK_EX)
            lockfile.seek(0)
            yield lockfile
            portalocker.lock(lockfile, portalocker.LOCK_UN)

    @contextlib.contextmanager
    def _explode_zip():
        # We need to update the actual variable; other modules are allowed to look at
        # these variables to find out what's going on (e.g. are we zip-safe or not).
        global PEX_PATH

        PEX_PATH, basepath, uniquedir, no_cache = pex_paths()
        os.makedirs(basepath, exist_ok=True)
        with pex_lockfile(basepath, uniquedir) as lockfile:
            if len(lockfile.read()) == 0:
                import compileall, zipfile

                os.makedirs(PEX_PATH, exist_ok=True)
                with plz.ZipFileWithPermissions(PEX, "r") as zf:
                    zf.extractall(PEX_PATH)

                if not no_cache:  # Don't bother optimizing; we're deleting this when we're done.
                    compileall.compile_dir(PEX_PATH, optimize=2, quiet=1)

                # Writing nonempty content to the lockfile will signal to subsequent invocations
                # that the cache has already been prepared.
                lockfile.write("pex unzip completed")
        sys.path = [PEX_PATH] + [x for x in sys.path if x != PEX]
        try:
            yield
        finally:
            if no_cache:
                import shutil
                shutil.rmtree(basepath)

    return _explode_zip


def profile(filename):
    """Returns a context manager to perform profiling while the program runs.

    This is triggered by setting the PEX_PROFILE_FILENAME env var to the destination file,
    at which point this will be invoked automatically at pex startup.
    """
    import contextlib, cProfile

    @contextlib.contextmanager
    def _profile():
        profiler = cProfile.Profile()
        profiler.enable()
        yield
        profiler.disable()
        sys.stderr.write('Writing profiler output to %s\n' % filename)
        profiler.dump_stats(filename)

    return _profile


# This must be redefined/implemented when the pex is built for debugging.
# The `DEBUG_PORT` environment variable should be used if the debugger is
# to be used as a server.
def start_debugger():
    pass


def main():
    """Runs the 'real' entry point of the pex.

    N.B. This gets redefined by pex_test_main to run tests instead.
    """
    # Starts a debugging session, if defined, before running the entry point.
    if os.getenv("PLZ_DEBUG") is not None:
        start_debugger()

    # Must run this as __main__ so it executes its own __name__ == '__main__' block.
    runpy.run_module(ENTRY_POINT, run_name='__main__')
    return 0  # unless some other exception gets raised, we're successful.
"""Customised test runner to output in JUnit-style XML."""

import os
import sys

# This will get templated in by the build rules.
TEST_NAMES = 'src/greetings/greetings_test.py'.split(',')


def initialise_coverage():
    """Imports & initialises the coverage module."""
    import coverage
    from coverage import control as coverage_control
    _original_xml_file = coverage_control.XmlReporter.xml_file
    # Fix up paths in coverage output which are absolute; we want paths relative to
    # the repository root. Also skip empty __init__.py files.

    def _xml_file(self, fr, analysis, *args, **kvargs):
        if PEX_PATH in fr.filename:
            fr.filename = fr.filename[len(PEX_PATH) + 1:]  # +1 to remove the remaining /
        if fr.filename == '__main__.py':
            return  # Don't calculate coverage for the synthetic entrypoint.
        if not (fr.filename.endswith('__init__.py') and len(analysis.statements) < 1):
            analysis.filename = fr.filename
            fr.relname = fr.filename
            _original_xml_file(self, fr, analysis, *args, **kvargs)
    coverage_control.XmlReporter.xml_file = _xml_file
    return coverage


def main():
    """Runs the tests. Returns an appropriate exit code."""
    args = [arg for arg in sys.argv[1:]]
    if os.getenv('COVERAGE'):
        # It's important that we run coverage while we load the tests otherwise
        # we get no coverage for import statements etc.
        cov = initialise_coverage().coverage(data_file=None)
        cov.exclude(r'^import\b')
        cov.exclude(r'^from\b')
        cov.start()
        result = run_tests(args)
        cov.stop()
        omissions = ['*/third_party/*', '*/.bootstrap/*']
        # Exclude test code from coverage itself.
        omissions.extend('*/%s.py' % module.replace('.', '/') for module in args)
        import coverage
        try:
            cov.xml_report(outfile=os.getenv('COVERAGE_FILE'), omit=omissions, ignore_errors=True)
        except coverage.CoverageException as err:
            # This isn't fatal; the main time we've seen it is raised for "No data to report" which
            # isn't an exception as far as we're concerned.
            sys.stderr.write('Failed to calculate coverage: %s' % err)
        return result
    else:
        # Starts a debugging session, if defined, before running the tests.
        if os.getenv("PLZ_DEBUG") is not None:
            start_debugger()

        return run_tests(args)
import os
import sys
import unittest
from importlib import import_module


def list_classes(suite):
    for test in suite:
        if isinstance(test, unittest.suite.TestSuite):
            for cls, name in list_classes(test):
                yield cls, name
        else:
            yield test, test.__class__.__module__ + '.' + test.id()


def get_suite(test_names, raise_on_empty=False):
    """
    Get the test suite to run the test

    :param test_names: Name of the tests to be filtered
    :param raise_on_empty: raise Exception if result filtered is empty

    :return: unittest.suite.TestSuite
    """
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module)
                               for module in import_tests())
    # Filter to test name only, this ensures the extra flags does not get swallowed
    test_names = list(filter(lambda x: not x.startswith('-'), test_names))

    # filter results if test_names is not empty
    if test_names:
        new_suite = unittest.suite.TestSuite()
        for name in test_names:
            new_suite.addTests(cls for cls, class_name in list_classes(suite)
                               if name in class_name)
        if raise_on_empty and suite.countTestCases() == 0:
            raise Exception('No matching tests found')

        return new_suite

    return suite


def import_tests():
    """Yields the set of test modules, from file if necessary."""
    # We have files available locally, but there may (likely) also be python files in the same
    # Python package within the pex. We can't just import them because the parent package exists
    # in only one of those places (this is similar to importing generated code from plz-out/gen).
    for filename in TEST_NAMES:
        pkg_name, _ = os.path.splitext(filename.replace('/', '.'))
        try:
            yield import_module(pkg_name)
        except ImportError:
            with open(filename, 'r') as f:
                mod = machinery.SourceFileLoader(pkg_name, filename).load_module()

                # Have to set the attribute on the parent module too otherwise some things
                # can't find it.
                parent, _, mod_name = pkg_name.rpartition('.')
                if parent and parent in sys.modules:
                    setattr(sys.modules[parent], mod_name, mod)
                yield mod


def run_tests(test_names):
    """Runs tests using unittest, returns the number of failures."""
    # N.B. import must be deferred until we have set up import paths.
    import xmlrunner
    suite = get_suite(test_names, raise_on_empty=True)

    runner = xmlrunner.XMLTestRunner(output='test.results', outsuffix='')
    results = runner.run(suite)
    return len(results.errors) + len(results.failures)
def run(explode=False):
    # Add .bootstrap dir to path, after the initial pex entry
    sys.path.insert(1, os.path.join(sys.path[0], '.bootstrap'))
    if explode or not ZIP_SAFE:
        with explode_zip()():
            add_module_dir_to_sys_path(MODULE_DIR, zip_safe=False)
            return main()
    else:
        add_module_dir_to_sys_path(MODULE_DIR)
        return main()


if __name__ == '__main__':
    # If PEX_EXPLODE is set, then it should always be exploded.
    explode = os.environ.get('PEX_EXPLODE', '0') != '0'

    # If PEX_INTERPRETER is set, then it starts an interactive console.
    if os.environ.get('PEX_INTERPRETER', '0') != '0':
        import code
        result = code.interact()
    # If PEX_PROFILE_FILENAME is set, then it collects profile information into the filename.
    elif os.environ.get('PEX_PROFILE_FILENAME'):
        with profile(os.environ['PEX_PROFILE_FILENAME'])():
            result = run(explode)
    else:
        result = run(explode)

    sys.exit(result)
