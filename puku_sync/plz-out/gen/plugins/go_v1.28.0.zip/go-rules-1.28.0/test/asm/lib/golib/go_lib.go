package golib

const LHS = 5
const RHS = 10
