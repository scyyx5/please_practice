#include "cgo.h"

int GetAnswer() {
  return 42;
}
