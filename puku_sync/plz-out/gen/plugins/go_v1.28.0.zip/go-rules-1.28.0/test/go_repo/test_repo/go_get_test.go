package test_repo

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestAssertImportable(t *testing.T) {
	assert.True(t, true)
}
