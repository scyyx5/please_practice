package foo

const Message = "Hello foo!"
