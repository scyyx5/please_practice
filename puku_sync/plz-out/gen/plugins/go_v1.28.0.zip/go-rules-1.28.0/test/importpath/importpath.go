// Package importpath is used to implement a test on Go import paths.
package importpath

// Answer is the answer to Life, the Universe and Everything.
const Answer = 42
