package root_test

import (
	"testing"

	"github.com/please-build/please-rules/root-test"
)

func TestRoot(t *testing.T) {
	_ = root.Foo()
}
