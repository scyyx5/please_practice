package root

import "testing"

func TestRoot(t *testing.T) {
	_ = Foo()
}
