package main

import (
	"fmt"
	"testrepo/src/foo"
)

func main() {
	fmt.Println(foo.Foo)
}
